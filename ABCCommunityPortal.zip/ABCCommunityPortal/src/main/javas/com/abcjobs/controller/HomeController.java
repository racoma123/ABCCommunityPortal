package com.abcjobs.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	@RequestMapping(value="/") // Home page
	public ModelAndView index() {
		return new ModelAndView("Home");
	}
	
	@RequestMapping(value="/Home") // Home page
	public ModelAndView home() {
		return new ModelAndView("/Home");
	}
	@RequestMapping(value="/ThankYouPage")// Thank You  page
	public ModelAndView thankyou(HttpServletResponse res) throws Exception {
		return new ModelAndView("ThankYouPage"); 
	}
	
	@RequestMapping(value="/EmailVerification") // Email Verification Page
	public ModelAndView EmailVerfied(HttpServletResponse res) throws Exception {
		return new ModelAndView("EmailVerification"); 
	}
	
	@RequestMapping(value="/verified") // Verified Page
	public ModelAndView Verfied(HttpServletResponse res) throws Exception {
		return new ModelAndView("verified"); 
	}
	
	@RequestMapping(value="/Login", method = RequestMethod.GET)
	public ModelAndView login(HttpSession session) throws Exception {
		return new ModelAndView("Login"); 
	}
	
	@RequestMapping(value="/ForgetPassword") //Forget Page
	public ModelAndView forgotPassword(HttpServletResponse res) throws Exception {
		return new ModelAndView("ForgetPassword");  
	}
	
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logout(HttpServletResponse res, HttpSession session) throws Exception {
		session.invalidate();

		Cookie eCookie = new Cookie("email", "");
		eCookie.setMaxAge(0); // 10 minute
		res.addCookie(eCookie);
		
		Cookie iCookie = new Cookie("userId", "");
		iCookie.setMaxAge(0);
		res.addCookie(iCookie);
		
		return "Login"; 
	}

}
