package com.abcjobs.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.abcjobs.model.Educations;
import com.abcjobs.model.Experiences;
import com.abcjobs.model.UserDetails;
import com.abcjobs.service.EducationsService;
import com.abcjobs.service.ExperiencesService;
import com.abcjobs.service.UserDetailsService;

@Controller
public class ProfileController {
	
	@Autowired
	UserDetailsService ud;
	
	@Autowired
	EducationsService eds;
	
	@Autowired
	ExperiencesService exs;
	
	
	@RequestMapping(value = "/Profile")
	public ModelAndView profile(HttpSession session, Model model) {
		try {
			this.setModel(model, session);
			return new ModelAndView("Profile");  
		} catch (Exception e) {
			System.out.println(e);
			String msg = "Login required";
			model.addAttribute("message", msg);
			return new ModelAndView("Login");
		}
	}
	
	
	@RequestMapping(value="/update-profile", method = RequestMethod.POST) // update profile POST
	public String up(
		@ModelAttribute("profile") UserDetails userDetails,
		
			@RequestParam("skills") String skill,
			@RequestParam("schoolName") String school,
			@RequestParam("courseName") String course, 
			@RequestParam("startedDate") String started,
			@RequestParam("EndDate") String endDate, 
			@RequestParam("companyName")String company, 
			@RequestParam("position") String position, 
			@RequestParam("startDate") String  startJob,
			@RequestParam("endDate") String EndJob, 
			Experiences experiences,
			Educations educations,
			Model model, HttpSession session) {
		
		Long userDetailsId = Long.parseLong(String.valueOf(session.getAttribute("userId")));
		
		userDetails.setSkill(skill);
		ud.updateProfile(userDetailsId, userDetails);
		
		if(school.equals("") || course.equals("") || started.equals("") || endDate.equals("")) {
			System.out.println("Experiences Empty");
		} else {
		educations.setUserDetailsId(String.valueOf(userDetailsId));
		educations.setSchoolName(school);
		educations.setCourseName(course);
		educations.setStartedDate(started);
		educations.setEndDate(endDate);
		
		
		eds.addEducations(educations);
		}
		
		
		
	if(position.equals("") || company.equals("") || startJob.equals("") || endDate.equals("")) {
			System.out.println("Experiences Empty");
		} else {
			// exs.updateExperiences(String.valueOf(userDetailsId), experiences);
			
			experiences.setCompanyName(company);
			experiences.setPosition(position);
			experiences.setStartDate(startJob);
			experiences.setEndDate(endDate);
			experiences.setUserDetailsId(String.valueOf(userDetailsId));
		
			exs.addExperiences(experiences);	
		}

	
		this.setModel(model, session);
		
		String msg = "Profile has been updated";
		model.addAttribute("message", msg);
		return "Profile";
	}
	
	private void setModel(Model model, HttpSession session) {
		String userId = String.valueOf(session.getAttribute("userId"));
		String[] userDetails = ud.getDetailsById(userId).replaceAll("null", "-").split(",");
		String udID = userDetails[0];
		
		model.addAttribute("f", userDetails[1].charAt(0));
		model.addAttribute("l", userDetails[2].charAt(0));
		
		model.addAttribute("firstName", userDetails[1]);
		model.addAttribute("lastName", userDetails[2]);
		
		model.addAttribute("fullName", userDetails[1] + " " + userDetails[2]);
		
		model.addAttribute("skills", userDetails[3]);
		
		
		// experiences
		model.addAttribute("ex", exs.getExperiencesByUserDetailsId(udID)); // Experiences[]
		
		// educations
		model.addAttribute("ed", eds.getEducationsByUserDetailsId(udID)); // Educations[]
		
		// notifications
		//List<BulkEmail> be = bes.getEmail(); 
		//model.addAttribute("nf1", be.get(be.size() - 1));
		//model.addAttribute("nf2", be.get(be.size() - 2));
		//model.addAttribute("nf3", be.get(be.size() - 3));
	}
}
