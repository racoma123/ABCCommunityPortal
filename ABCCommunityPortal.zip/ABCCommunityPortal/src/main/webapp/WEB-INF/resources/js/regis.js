/**
 * 
 */
const form =document.querySelector("form"),
    emailField =form.querySelector(".email-field"),
    emailInput =emailField.querySelector(".email"),
    passField =form.querySelector(".create-password"),
    passInput =passField.querySelector(".password"),
    cPassField =form.querySelector(".confirm-password"),
    cPassInput =cPassField.querySelector(".cPassword");

//Email Validation
function checkEmail(){
    const emaiPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(!emailInput.value.match(emaiPattern)){
        return emailField.classList.add("invalid");//adding invalid class if email value  do not matched
    }
    emailField.classList.remove("invalid");

}
//hide and show password

const eyeIcons=document.querySelectorAll(".show-hide");

eyeIcons.forEach(eyeIcons=>{
    eyeIcons.addEventListener("click",()=>{
        const pInput = eyeIcons.parentElement.querySelector("input");
        // eyeIcons.classList.replace("bx-hide","bx-show");
        if(pInput.type ==="password"){
            eyeIcons.classList.replace("bx-hide","bx-show");
            return(pInput.type="text");
        }
        eyeIcons.classList.replace("bx-show","bx-hide");
        return(pInput.type="password");

    });
});

//password validation
function createPass(){
    const passPattern =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if(!passInput.value.match(passPattern)){
    return passField.classList.add("invalid");
 }
  passField.classList.remove("invalid");
}

//confirmation password validation
function confirmPass(){
        if(passInput.value !== cPassInput.value || cPassInput.value ===""){
        return cPassField.classList.add("invalid");
        }
        cPassField.classList.remove("invalid");
  
}

// calling Function on Form submit
form.addEventListener("submit",(e)=>{
  e.preventDefault();
    // Preventing form submitting
    checkEmail();
    createPass();
    confirmPass();
    //calling function on key up
    emailInput.addEventListener("keyup",checkEmail);
    passInput.addEventListener("keyup",createPass);
    cPassInput.addEventListener("keyup",confirmPass);
  
});


