/**
 * 
 */
const form = document.getElementById('form')
const error =[]
form.addEventListener('submit',function(e){
	e.preventDefault() //// Preventing form submitting
	
	
	const userName= document.getElementById('fname')
		const lastName= document.getElementById('lname')
		if(userName ===" "){
			error.push("Please Enter First Name")
			}
		if(lastName ===""){
		error.push("Please Enter Last Name")
		}
		
		const message =document.getElementById('message')
		message.innerHTML =error;
})